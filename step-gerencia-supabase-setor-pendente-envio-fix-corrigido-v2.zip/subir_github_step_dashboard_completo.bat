@echo off
setlocal

echo ========================================
echo   SUBIR PROJETO PARA O GITHUB

echo ========================================

set REPO_URL=https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
set BRANCH=main

cd /d "%~dp0"

if not exist ".git" (
  git init
)

git branch -M %BRANCH%
git remote remove origin >nul 2>nul
git remote add origin %REPO_URL%

git add .
git commit -m "Atualizacao do projeto" || echo Nenhuma alteracao para commit.
git push -u origin %BRANCH%

echo.
echo Concluido.
pause
