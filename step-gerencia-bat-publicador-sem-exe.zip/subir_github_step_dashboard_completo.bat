@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ==============================================
echo   SUBIR PROJETO PARA O GITHUB SEM ENVIAR O APP
 echo ==============================================
echo.

where git >nul 2>nul
if errorlevel 1 (
  echo ERRO: Git nao encontrado no sistema.
  echo Instale o Git e tente novamente.
  pause
  exit /b 1
)

set /p REPO_URL=Cole a URL do repositorio GitHub (ex: https://github.com/usuario/repositorio.git): 
if "%REPO_URL%"=="" (
  echo ERRO: repositorio nao informado.
  pause
  exit /b 1
)

set /p BRANCH_NAME=Informe a branch [main]: 
if "%BRANCH_NAME%"=="" set BRANCH_NAME=main

set /p COMMIT_MSG=Mensagem do commit [Atualizacao do projeto]: 
if "%COMMIT_MSG%"=="" set COMMIT_MSG=Atualizacao do projeto

echo.
echo Preparando repositorio...
if not exist ".git" (
  git init
  if errorlevel 1 goto :git_error
)

git branch -M "%BRANCH_NAME%" >nul 2>nul

git remote get-url origin >nul 2>nul
if errorlevel 1 (
  git remote add origin "%REPO_URL%"
) else (
  git remote set-url origin "%REPO_URL%"
)
if errorlevel 1 goto :git_error

echo.
echo Adicionando arquivos...
git add .
if errorlevel 1 goto :git_error

REM Remove da stage o proprio publicador para nao subir
for %%F in (
  "subir_github_step_dashboard_completo.bat"
  "subir_github_step_dashboard_completo.exe"
  "subir_github_step_dashboard_completo.cmd"
) do (
  git reset -q HEAD -- %%~F 2>nul
)

REM Tambem tenta remover o executavel com o mesmo nome do arquivo atual, caso tenha sido convertido para EXE
set "SELF_BAT=%~nx0"
set "SELF_EXE=%~n0.exe"
git reset -q HEAD -- "%SELF_BAT%" 2>nul
git reset -q HEAD -- "%SELF_EXE%" 2>nul

echo.
echo Criando commit...
git diff --cached --quiet
if not errorlevel 1 (
  echo Nenhuma alteracao para enviar depois das exclusoes.
  pause
  exit /b 0
)

git commit -m "%COMMIT_MSG%"
if errorlevel 1 goto :git_error

echo.
echo Enviando para o GitHub...
git push -u origin "%BRANCH_NAME%"
if errorlevel 1 goto :git_error

echo.
echo Concluido com sucesso.
echo O projeto foi enviado sem subir este publicador.
pause
exit /b 0

:git_error
echo.
echo Ocorreu um erro ao executar o Git.
echo Verifique a autenticacao, a URL do repositorio e as permissoes.
pause
exit /b 1
